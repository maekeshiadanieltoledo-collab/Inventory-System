<?php
include "config.php";

// Only users can access
if(!isset($_SESSION['role']) || $_SESSION['role'] != 'user'){
    header("Location: index.php");
    exit;
}
?>

<h2>User Dashboard</h2>

<p>Welcome, User!</p>

<ul>
    <li><a href="add_item.php">Add Item</a></li>
    <li><a href="view_items.php">View Items</a></li>
    <li><a href="logout.php">Logout</a></li>
	<li><a href="change_password.php">Change Password</a></li>
	<li><a href="graph.php">View Item History Graph</a></li>
</ul>