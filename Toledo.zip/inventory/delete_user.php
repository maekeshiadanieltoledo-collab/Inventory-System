<?php
include "config.php";

// Only admins can access
if(!isset($_SESSION['role']) || $_SESSION['role'] != 'admin'){
    header("Location: index.php");
    exit;
}

// Delete user if ?id=xx is set
if(isset($_GET['id'])){
    $id = $_GET['id'];
    $conn->query("DELETE FROM users WHERE id='$id'");
    echo "User deleted!<br><br>";
}

// Show all users
$result = $conn->query("SELECT * FROM users");
?>

<h2>Delete Users</h2>

<?php
while($row = $result->fetch_assoc()){
    echo $row['username'] . " - " . $row['role'];
    echo " <a href='delete_user.php?id=".$row['id']."'>Delete</a><br>";
}
?>

<br>
<a href="admin.php">Back to Dashboard</a>