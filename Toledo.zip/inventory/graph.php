<?php
include "config.php";

// Only logged in users (admin or user) can access
if(!isset($_SESSION['role'])){
    header("Location: index.php");
    exit;
}

// Get all items
$items = [];
$item_result = $conn->query("SELECT * FROM items");
while($row = $item_result->fetch_assoc()){
    $items[$row['id']] = $row['item_name'];
}

// If ?item_id is set, show that item, otherwise first item
$item_id = isset($_GET['item_id']) ? $_GET['item_id'] : key($items);

// Get item history
$history = $conn->query("SELECT * FROM item_history WHERE item_id='$item_id' ORDER BY changed_at ASC");

$labels = [];
$data = [];
while($h = $history->fetch_assoc()){
    $labels[] = $h['changed_at'];
    $data[] = $h['quantity'];
}
?>

<h2>Item History Graph</h2>

<form method="GET">
    Select Item:
    <select name="item_id" onchange="this.form.submit()">
        <?php foreach($items as $id => $name){ ?>
            <option value="<?php echo $id; ?>" <?php if($id==$item_id) echo "selected"; ?>><?php echo $name; ?></option>
        <?php } ?>
    </select>
</form>

<canvas id="myChart" width="600" height="400"></canvas>

<script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
<script>
const ctx = document.getElementById('myChart').getContext('2d');
const myChart = new Chart(ctx, {
    type: 'line',
    data: {
        labels: <?php echo json_encode($labels); ?>,
        datasets: [{
            label: 'Quantity',
            data: <?php echo json_encode($data); ?>,
            fill: false,
            borderColor: 'blue',
            tension: 0.1
        }]
    },
});
</script>

<br>
<a href="user.php">Back to Dashboard</a>