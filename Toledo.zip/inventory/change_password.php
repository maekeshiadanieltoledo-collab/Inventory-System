<?php
include "config.php";

// Must be logged in
if(!isset($_SESSION['role'])){
    header("Location: index.php");
    exit;
}

$user_id = $_SESSION['user_id'];

if(isset($_POST['change'])){
    $old = $_POST['old'];
    $new = $_POST['new'];

    // Get current password
    $result = $conn->query("SELECT password FROM users WHERE id='$user_id'");
    $row = $result->fetch_assoc();

    if($old == $row['password']){ // super simple, no hash
        $conn->query("UPDATE users SET password='$new' WHERE id='$user_id'");
        echo "Password changed!";
    } else {
        echo "Old password is incorrect!";
    }
}
?>

<h2>Change Password</h2>

<form method="POST">
    Old Password: <input type="text" name="old" required><br>
    New Password: <input type="text" name="new" required><br>
    <button type="submit" name="change">Change</button>
</form>

<br>
<?php
if($_SESSION['role'] == 'admin'){
    echo '<a href="admin.php">Back to Dashboard</a>';
}else{
    echo '<a href="user.php">Back to Dashboard</a>';
}
?>