<?php
include "config.php";

// Only users can access
if(!isset($_SESSION['role']) || $_SESSION['role'] != 'user'){
    header("Location: index.php");
    exit;
}

if(isset($_POST['add'])){
    $item_name = $_POST['item_name'];
    $quantity = $_POST['quantity'];

    $conn->query("INSERT INTO items (item_name, quantity) VALUES ('$item_name', '$quantity')");

    // Add log
    $user_id = $_SESSION['user_id'];
    $conn->query("INSERT INTO logs (user_id, action) VALUES ('$user_id', 'Added item $item_name')");

    // Add to item history
    $item_id = $conn->insert_id;
    $conn->query("INSERT INTO item_history (item_id, quantity) VALUES ('$item_id', '$quantity')");

    echo "Item added!";
}
?>

<h2>Add Item</h2>

<form method="POST">
    Item Name: <input type="text" name="item_name" required><br>
    Quantity: <input type="number" name="quantity" required><br>
    <button type="submit" name="add">Add Item</button>
</form>

<br>
<a href="user.php">Back to Dashboard</a>