<?php
session_start();
session_destroy(); // end the session
header("Location: index.php"); // redirect to login page
exit;
?>