<?php
include "config.php";

// Only admins can access
if(!isset($_SESSION['role']) || $_SESSION['role'] != 'admin'){
    header("Location: index.php");
    exit;
}

// Get logs with username
$result = $conn->query("
    SELECT logs.*, users.username 
    FROM logs 
    LEFT JOIN users ON logs.user_id = users.id
");
if(!$result){
    die("Query failed: " . $conn->error);
}
?>

<h2>History Logs</h2>

<?php
while($row = $result->fetch_assoc()){
    echo $row['username'] . " - " . $row['action'] . " - " . $row['created_at'] . "<br>";
}
?>

<br>
<a href="admin.php">Back to Dashboard</a>