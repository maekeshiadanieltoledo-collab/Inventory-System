<?php
include "config.php";

// Only users can access
if(!isset($_SESSION['role']) || $_SESSION['role'] != 'user'){
    header("Location: index.php");
    exit;
}

// Check if form submitted
if(isset($_POST['update'])){
    $id = $_POST['id'];
    $quantity = $_POST['quantity'];

    $conn->query("UPDATE items SET quantity='$quantity' WHERE id='$id'");

    echo "Quantity updated!";
}
if(isset($_POST['update'])){
    $id = $_POST['id'];
    $quantity = $_POST['quantity'];

    $conn->query("UPDATE items SET quantity='$quantity' WHERE id='$id'");

    // Log the edit
    $user_id = $_SESSION['user_id'];
    $result = $conn->query("SELECT item_name FROM items WHERE id='$id'");
    $row = $result->fetch_assoc();
    $conn->query("INSERT INTO logs (user_id, action) VALUES ('$user_id', 'Updated ".$row['item_name']." quantity to $quantity')");

    // Add to item_history
    $conn->query("INSERT INTO item_history (item_id, quantity) VALUES ('$id', '$quantity')");

    echo "Quantity updated!";

}

// Get item info if ?id=xx
if(isset($_GET['id'])){
    $id = $_GET['id'];
    $result = $conn->query("SELECT * FROM items WHERE id='$id'");
    $row = $result->fetch_assoc();
}
?>

<h2>Edit Item Quantity</h2>

<form method="POST">
    <input type="hidden" name="id" value="<?php echo $row['id']; ?>">
    Item: <?php echo $row['item_name']; ?><br>
    Quantity: <input type="number" name="quantity" value="<?php echo $row['quantity']; ?>" required><br>
    <button type="submit" name="update">Update</button>
</form>

<br>
<a href="view_items.php">Back to Items</a>