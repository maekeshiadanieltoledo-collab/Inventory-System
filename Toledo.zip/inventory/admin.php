<?php
include "config.php";

// Only admins can access
if(!isset($_SESSION['role']) || $_SESSION['role'] != 'admin'){
    header("Location: index.php");
    exit;
}
?>

<h2>Admin Dashboard</h2>

<p>Welcome, Admin!</p>

<ul>
    <li><a href="create_user.php">Create User</a></li>
    <li><a href="view_logs.php">View Logs</a></li>
    <li><a href="logout.php">Logout</a></li>
	<li><a href="delete_user.php">Delete Users</a></li>
	<li><a href="change_password.php">Change Password</a></li>
	<li><a href="graph.php">View Item History Graph</a></li>
</ul>