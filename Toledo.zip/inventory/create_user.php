<?php
include "config.php";

// Only admin can access
if(!isset($_SESSION['role']) || $_SESSION['role'] != 'admin'){
    header("Location: index.php");
    exit;
}

if(isset($_POST['create'])){
    $username = $_POST['username'];
    $password = $_POST['password'];
    $role = $_POST['role'];

    $conn->query("INSERT INTO users (username,password,role) VALUES ('$username','$password','$role')");
    echo "User created!";
}
?>

<h2>Create User</h2>

<form method="POST">
    Username: <input type="text" name="username" required><br>
    Password: <input type="text" name="password" required><br>
    Role: 
    <select name="role">
        <option value="user">User</option>
        <option value="admin">Admin</option>
    </select><br>
    <button type="submit" name="create">Create</button>
</form>

<br>
<a href="admin.php">Back to Dashboard</a>