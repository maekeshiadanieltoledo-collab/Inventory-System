<?php
include "config.php";

// Only users can access
if(!isset($_SESSION['role']) || $_SESSION['role'] != 'user'){
    header("Location: index.php");
    exit;
}

$result = $conn->query("SELECT * FROM items");
?>

<h2>Items</h2>

<?php
while($row = $result->fetch_assoc()){
    echo $row['item_name'] . " - " . $row['quantity']; 
    echo " <a href='edit_item.php?id=".$row['id']."'>Edit</a><br>";
}
?>

<br>
<a href="user.php">Back to Dashboard</a>